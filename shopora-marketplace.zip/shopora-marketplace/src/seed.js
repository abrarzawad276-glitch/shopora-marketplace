require('dotenv').config();
const bcrypt = require('bcryptjs');
const { nanoid } = require('nanoid');
const db = require('./db');
(async () => {
  const sellerId = 'demo-seller-001';
  if (!db.prepare('SELECT id FROM users WHERE id=?').get(sellerId)) {
    const hash = await bcrypt.hash('ShoporaDemo123', 12);
    db.prepare('INSERT INTO users(id,name,email,phone,password_hash,role) VALUES(?,?,?,?,?,?)')
      .run(sellerId, 'Shopora Demo Store', 'seller@shopora.demo', '01700000001', hash, 'seller');
  }
  const demo = [
    ['Wireless Bluetooth Headphone','দৈনন্দিন ব্যবহারের জন্য আরামদায়ক ওয়্যারলেস হেডফোন।',1290,25,'ইলেকট্রনিক্স','🎧'],
    ['Classic Everyday Backpack','স্কুল, কলেজ ও ভ্রমণের জন্য ব্যবহার উপযোগী ব্যাকপ্যাক।',890,40,'ফ্যাশন','🎒'],
    ['Minimal Desk Lamp','পড়াশোনা ও কাজের টেবিলের জন্য মিনিমাল ডিজাইনের ল্যাম্প।',750,18,'হোম ও লাইফস্টাইল','💡'],
    ['Daily Care Skincare Set','দৈনন্দিন ত্বক পরিচর্যার সাধারণ সেট।',990,30,'সৌন্দর্য','🧴'],
    ['Cotton Casual T-Shirt','আরামদায়ক কটন ক্যাজুয়াল টি-শার্ট।',450,60,'ফ্যাশন','👕'],
    ['Portable Mini Speaker','ছোট আকারের পোর্টেবল ব্লুটুথ স্পিকার।',1590,12,'ইলেকট্রনিক্স','🔊'],
    ['Ceramic Coffee Mug','ঘরে বা অফিসে ব্যবহারের জন্য সিরামিক মগ।',320,50,'হোম ও লাইফস্টাইল','☕'],
    ['Everyday Tote Bag','হালকা ও ব্যবহারিক টোট ব্যাগ।',520,22,'ফ্যাশন','👜']
  ];
  for (const [title,description,price,stock,category] of demo) {
    if (!db.prepare('SELECT id FROM products WHERE title=?').get(title)) {
      db.prepare('INSERT INTO products(id,seller_id,title,description,price,stock,category,variants,discount_percent,discount_ends_at) VALUES(?,?,?,?,?,?,?,?,?,?)')
        .run(nanoid(), sellerId, title, description, price, stock, category, JSON.stringify({রং:['কালো','সাদা'],সাইজ:['Standard']}), 10, new Date(Date.now()+2*86400000).toISOString());
    }
  }
  console.log('ডেমো ডেটা তৈরি হয়েছে। Seller login: seller@shopora.demo / ShoporaDemo123');
  process.exit(0);
})();
