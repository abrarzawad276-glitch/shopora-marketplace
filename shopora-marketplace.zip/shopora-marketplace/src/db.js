const Database = require('better-sqlite3');
const db = new Database('shopora.sqlite');
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id TEXT PRIMARY KEY, name TEXT NOT NULL, email TEXT UNIQUE, phone TEXT UNIQUE,
 password_hash TEXT, role TEXT NOT NULL DEFAULT 'buyer', created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS products (
 id TEXT PRIMARY KEY, seller_id TEXT NOT NULL, title TEXT NOT NULL, description TEXT DEFAULT '',
 price REAL NOT NULL, stock INTEGER NOT NULL DEFAULT 0, category TEXT DEFAULT 'অন্যান্য',
 image TEXT DEFAULT '', video TEXT DEFAULT '', variants TEXT DEFAULT '{}', discount_percent INTEGER DEFAULT 0,
 discount_ends_at TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(seller_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS reviews (
 id TEXT PRIMARY KEY, product_id TEXT NOT NULL, user_id TEXT NOT NULL, rating INTEGER NOT NULL,
 comment TEXT DEFAULT '', photo TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS orders (
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL, items TEXT NOT NULL, subtotal REAL NOT NULL,
 delivery_fee REAL NOT NULL DEFAULT 60, total REAL NOT NULL, payment_method TEXT NOT NULL,
 payment_status TEXT NOT NULL DEFAULT 'pending', status TEXT NOT NULL DEFAULT 'placed',
 address TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS support_tickets (
 id TEXT PRIMARY KEY, user_id TEXT, subject TEXT NOT NULL, message TEXT NOT NULL,
 status TEXT DEFAULT 'open', created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
`);
module.exports = db;
