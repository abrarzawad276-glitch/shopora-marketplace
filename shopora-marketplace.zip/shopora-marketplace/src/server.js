require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const multer = require('multer');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { nanoid } = require('nanoid');
const path = require('path');
const fs = require('fs');
const db = require('./db');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'development-only-change-this-secret';
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: process.env.PUBLIC_BASE_URL || true }));
app.use(express.json({ limit: '2mb' }));
app.use('/uploads', express.static(path.join(__dirname, '../uploads')));
app.use(express.static(path.join(__dirname, '../public')));
app.use('/api/auth', rateLimit({ windowMs: 15 * 60 * 1000, limit: 30 }));

const uploadDir = path.join(__dirname, '../uploads');
fs.mkdirSync(uploadDir, { recursive: true });
const upload = multer({ dest: uploadDir, limits: { fileSize: 15 * 1024 * 1024 }, fileFilter: (_, file, cb) => {
  cb(null, /^(image\/(jpeg|png|webp)|video\/mp4)$/.test(file.mimetype));
}});
const otpStore = new Map(); // Demo only. Use Redis + an SMS provider in production.

function auth(req, res, next) {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  try { req.user = jwt.verify(token, JWT_SECRET); next(); }
  catch { res.status(401).json({ error: 'লগইন প্রয়োজন' }); }
}
function optionalAuth(req, _res, next) {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  try { req.user = jwt.verify(token, JWT_SECRET); } catch { req.user = null; }
  next();
}
function safeUser(row) { return row && { id: row.id, name: row.name, email: row.email, phone: row.phone, role: row.role }; }

app.get('/api/health', (_req, res) => res.json({ ok: true, name: 'Shopora API' }));

// Password registration/login. Phone OTP endpoints below are demo-only until SMS provider is connected.
app.post('/api/auth/register', async (req, res) => {
  const { name, email, phone, password, role = 'buyer' } = req.body || {};
  if (!name || (!email && !phone) || !password || String(password).length < 8)
    return res.status(400).json({ error: 'নাম, ইমেইল অথবা ফোন এবং কমপক্ষে ৮ অক্ষরের পাসওয়ার্ড দিন' });
  if (!['buyer', 'seller'].includes(role)) return res.status(400).json({ error: 'অবৈধ role' });
  try {
    const id = nanoid(); const hash = await bcrypt.hash(password, 12);
    db.prepare('INSERT INTO users(id,name,email,phone,password_hash,role) VALUES(?,?,?,?,?,?)').run(id, name, email || null, phone || null, hash, role);
    const token = jwt.sign({ id, name, role }, JWT_SECRET, { expiresIn: '7d' });
    res.status(201).json({ token, user: { id, name, email, phone, role } });
  } catch { res.status(409).json({ error: 'এই ইমেইল বা ফোন আগে থেকেই ব্যবহৃত হয়েছে' }); }
});
app.post('/api/auth/login', async (req, res) => {
  const { identifier, password } = req.body || {};
  const user = db.prepare('SELECT * FROM users WHERE email=? OR phone=?').get(identifier, identifier);
  if (!user || !user.password_hash || !(await bcrypt.compare(password || '', user.password_hash)))
    return res.status(401).json({ error: 'তথ্য সঠিক নয়' });
  const token = jwt.sign({ id: user.id, name: user.name, role: user.role }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user: safeUser(user) });
});
app.post('/api/auth/otp/request', (req, res) => {
  const { phone } = req.body || {};
  if (!/^\+?8801[3-9]\d{8}$/.test(String(phone || '').replace(/[- ]/g, '')))
    return res.status(400).json({ error: 'সঠিক বাংলাদেশি মোবাইল নম্বর দিন' });
  const code = String(Math.floor(100000 + Math.random() * 900000));
  otpStore.set(phone, { code, expires: Date.now() + 5 * 60 * 1000 });
  // Never expose OTP in API response. Demo OTP is printed only in server terminal.
  console.log(`[DEMO OTP] ${phone}: ${code}`);
  res.json({ message: 'ডেমো OTP তৈরি হয়েছে। ডেভেলপমেন্টে সার্ভার টার্মিনাল দেখুন।', demo: process.env.OTP_PROVIDER === 'demo' });
});
app.post('/api/auth/otp/verify', (req, res) => {
  const { phone, code, name = 'নতুন ব্যবহারকারী', role = 'buyer' } = req.body || {};
  const record = otpStore.get(phone);
  if (!record || record.expires < Date.now() || record.code !== String(code)) return res.status(400).json({ error: 'OTP ভুল অথবা মেয়াদ শেষ' });
  otpStore.delete(phone);
  let user = db.prepare('SELECT * FROM users WHERE phone=?').get(phone);
  if (!user) { const id = nanoid(); db.prepare('INSERT INTO users(id,name,phone,role) VALUES(?,?,?,?)').run(id, name, phone, role); user = db.prepare('SELECT * FROM users WHERE id=?').get(id); }
  const token = jwt.sign({ id: user.id, name: user.name, role: user.role }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user: safeUser(user) });
});
app.get('/api/me', auth, (req, res) => res.json({ user: safeUser(db.prepare('SELECT * FROM users WHERE id=?').get(req.user.id)) }));

app.get('/api/products', (req, res) => {
  const { q = '', category = '', sort = 'newest' } = req.query;
  const order = sort === 'price_asc' ? 'p.price ASC' : sort === 'price_desc' ? 'p.price DESC' : 'p.created_at DESC';
  const rows = db.prepare(`SELECT p.*, u.name seller_name, (SELECT ROUND(AVG(rating),1) FROM reviews WHERE product_id=p.id) rating,
    (SELECT COUNT(*) FROM reviews WHERE product_id=p.id) review_count FROM products p JOIN users u ON u.id=p.seller_id
    WHERE (p.title LIKE ? OR p.description LIKE ?) AND (?='' OR p.category=?) ORDER BY ${order}`).all(`%${q}%`, `%${q}%`, category, category);
  res.json(rows.map(p => ({ ...p, variants: JSON.parse(p.variants || '{}') })));
});
app.get('/api/products/:id', (req, res) => {
  const p = db.prepare(`SELECT p.*,u.name seller_name FROM products p JOIN users u ON u.id=p.seller_id WHERE p.id=?`).get(req.params.id);
  if (!p) return res.status(404).json({ error: 'পণ্য পাওয়া যায়নি' });
  p.variants = JSON.parse(p.variants || '{}');
  p.reviews = db.prepare(`SELECT r.*,u.name reviewer FROM reviews r JOIN users u ON u.id=r.user_id WHERE product_id=? ORDER BY r.created_at DESC`).all(p.id);
  res.json(p);
});
app.post('/api/products', auth, upload.fields([{ name: 'image', maxCount: 1 }, { name: 'video', maxCount: 1 }]), (req, res) => {
  if (req.user.role !== 'seller') return res.status(403).json({ error: 'শুধু বিক্রেতারা পণ্য যোগ করতে পারবেন' });
  const { title, description = '', price, stock = 0, category = 'অন্যান্য', variants = '{}', discount_percent = 0, discount_ends_at = null } = req.body;
  if (!title || !(Number(price) > 0)) return res.status(400).json({ error: 'পণ্যের নাম ও সঠিক দাম আবশ্যক' });
  const image = req.files?.image?.[0] ? `/uploads/${req.files.image[0].filename}` : '';
  const video = req.files?.video?.[0] ? `/uploads/${req.files.video[0].filename}` : '';
  const id = nanoid();
  db.prepare(`INSERT INTO products(id,seller_id,title,description,price,stock,category,image,video,variants,discount_percent,discount_ends_at)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`).run(id, req.user.id, title, description, Number(price), Number(stock), category, image, video, variants, Math.min(90, Math.max(0, Number(discount_percent))), discount_ends_at || null);
  res.status(201).json({ id, message: 'পণ্য যোগ হয়েছে' });
});
app.post('/api/products/:id/reviews', auth, upload.single('photo'), (req, res) => {
  const { rating, comment = '' } = req.body;
  if (!db.prepare('SELECT id FROM products WHERE id=?').get(req.params.id)) return res.status(404).json({ error: 'পণ্য পাওয়া যায়নি' });
  if (!Number.isInteger(Number(rating)) || rating < 1 || rating > 5) return res.status(400).json({ error: '১ থেকে ৫ স্টার দিন' });
  const id = nanoid(); const photo = req.file ? `/uploads/${req.file.filename}` : '';
  db.prepare('INSERT INTO reviews(id,product_id,user_id,rating,comment,photo) VALUES(?,?,?,?,?,?)').run(id, req.params.id, req.user.id, rating, comment, photo);
  res.status(201).json({ id, message: 'রিভিউ জমা হয়েছে' });
});
app.get('/api/sellers/:id', (req, res) => {
  const seller = db.prepare('SELECT id,name,created_at FROM users WHERE id=? AND role="seller"').get(req.params.id);
  if (!seller) return res.status(404).json({ error: 'দোকান পাওয়া যায়নি' });
  seller.products = db.prepare('SELECT * FROM products WHERE seller_id=? ORDER BY created_at DESC').all(seller.id);
  res.json(seller);
});
app.get('/api/seller/products', auth, (req, res) => {
  if (req.user.role !== 'seller') return res.status(403).json({ error: 'বিক্রেতা অ্যাকাউন্ট প্রয়োজন' });
  res.json(db.prepare('SELECT * FROM products WHERE seller_id=? ORDER BY created_at DESC').all(req.user.id));
});

app.post('/api/orders', auth, (req, res) => {
  const { items, address, payment_method = 'cash_on_delivery' } = req.body || {};
  if (!Array.isArray(items) || !items.length || !address) return res.status(400).json({ error: 'কার্ট ও ডেলিভারি ঠিকানা দিন' });
  let subtotal = 0; const normalized = [];
  for (const item of items) {
    const p = db.prepare('SELECT id,title,price,stock,discount_percent,discount_ends_at FROM products WHERE id=?').get(item.product_id);
    const qty = Math.max(1, Math.floor(Number(item.quantity) || 1));
    if (!p || p.stock < qty) return res.status(400).json({ error: `${p?.title || 'একটি পণ্য'} পর্যাপ্ত স্টকে নেই` });
    const discountActive = p.discount_ends_at && new Date(p.discount_ends_at).getTime() > Date.now();
    const unit = discountActive ? p.price * (1 - p.discount_percent / 100) : p.price;
    subtotal += unit * qty; normalized.push({ product_id: p.id, title: p.title, quantity: qty, unit_price: unit });
  }
  const delivery = 60; const id = nanoid();
  db.prepare('INSERT INTO orders(id,user_id,items,subtotal,delivery_fee,total,payment_method,address) VALUES(?,?,?,?,?,?,?,?)')
    .run(id, req.user.id, JSON.stringify(normalized), subtotal, delivery, subtotal + delivery, payment_method, address);
  const reduce = db.prepare('UPDATE products SET stock=stock-? WHERE id=?');
  normalized.forEach(i => reduce.run(i.quantity, i.product_id));
  res.status(201).json({ id, subtotal, delivery_fee: delivery, total: subtotal + delivery, status: 'placed', payment_status: 'pending' });
});
app.get('/api/orders', auth, (req, res) => res.json(db.prepare('SELECT * FROM orders WHERE user_id=? ORDER BY created_at DESC').all(req.user.id).map(o => ({ ...o, items: JSON.parse(o.items) }))));
app.post('/api/support', optionalAuth, (req, res) => {
  const { subject, message } = req.body || {};
  if (!subject || !message) return res.status(400).json({ error: 'বিষয় ও বার্তা লিখুন' });
  const id = nanoid(); db.prepare('INSERT INTO support_tickets(id,user_id,subject,message) VALUES(?,?,?,?)').run(id, req.user?.id || null, subject, message);
  res.status(201).json({ id, message: 'সাপোর্ট অনুরোধ জমা হয়েছে' });
});

app.get('*', (_req, res) => res.sendFile(path.join(__dirname, '../public/index.html')));
app.listen(PORT, () => console.log(`Shopora চলছে: http://localhost:${PORT}`));
