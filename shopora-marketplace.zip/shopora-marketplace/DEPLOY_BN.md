# SHOPORA — বিনামূল্যে অনলাইন ডেমো প্রকাশের নির্দেশিকা

এই নির্দেশিকা Render-এর Free Web Service-এ বর্তমান starter-টি পরীক্ষামূলকভাবে প্রকাশ করার জন্য। এটি production ecommerce hosting নয়।

## প্রকাশের আগে গুরুত্বপূর্ণ সীমাবদ্ধতা

- Render Free Web Service ১৫ মিনিট নিষ্ক্রিয় থাকলে sleep করে; পরের ভিজিটে জেগে উঠতে প্রায় এক মিনিট লাগতে পারে।
- এই starter SQLite ব্যবহার করে। Render Free instance-এর local filesystem স্থায়ী নয়; restart/redeploy/spin-down হলে database ও আপলোড করা ফাইল হারাতে পারে। তাই এখানে বাস্তব ক্রেতা, বিক্রেতা, অর্ডার, ব্যক্তিগত তথ্য বা আসল ব্যবসার ডেটা রাখবেন না।
- Demo OTP সার্ভারের log-এ যায়; SMS পাঠায় না। Google/Facebook OAuth এবং bKash/Nagad পেমেন্ট চালু নয়।
- Free hosting-এর নিয়ম/সীমা পরিবর্তন হতে পারে। প্রকাশের আগে Render-এর official free-plan documentation দেখে নিন।

## ধাপ ১ — ZIP Extract ও GitHub-এ কোড আপলোড

1. `shopora-marketplace.zip` কম্পিউটারে Extract করুন।
2. GitHub-এ একটি নতুন private repository তৈরি করুন (যেমন `shopora-demo`)। অ্যাকাউন্ট তৈরি/ব্যবহারে প্রয়োজন হলে অভিভাবকের সহায়তা নিন।
3. Extract করা ফোল্ডারের ভেতরের সব ফাইল repository-তে upload করুন। `shopora-marketplace` নামে অতিরিক্ত nested folder যেন না থাকে; `package.json` repository root-এ থাকতে হবে।
4. `.env` বা কোনো আসল secret upload করবেন না। `.gitignore`-এ `.env` বাদ দেওয়া আছে।

## ধাপ ২ — Render-এ প্রকাশ

1. Render-এ প্রবেশ করে GitHub repository সংযুক্ত করুন।
2. Dashboard থেকে **New → Blueprint** বেছে নিয়ে `shopora-demo` repository নির্বাচন করুন।
3. Render root-এ থাকা `render.yaml` পড়ে `shopora-demo` নামে Free Web Service তৈরি করবে।
4. `JWT_SECRET`-এর জন্য Render স্বয়ংক্রিয় random value তৈরি করবে। এটি কাউকে পাঠাবেন না।
5. Deploy শেষ হলে Render একটি `https://...onrender.com` ঠিকানা দেবে। সেটি খুলুন।
6. `https://আপনার-সাইট/api/health` খুললে `{"ok":true,"name":"Shopora API"}` এলে সার্ভার সাড়া দিচ্ছে।

## ধাপ ৩ — পরীক্ষা

- Home page, search, category filter, product details দেখুন।
- Demo seller account: `seller@shopora.demo`
- Demo seller password: `ShoporaDemo123`
- শুধু পরীক্ষামূলক পণ্য/অর্ডার ব্যবহার করুন। বাস্তব ব্যক্তিগত তথ্য বা পেমেন্ট তথ্য দেবেন না।

## মোবাইল থেকে

কম্পিউটারে GitHub/Render সেটআপ সহজ। মোবাইলের Chrome-এ Desktop site চালু করেও করা যায়, তবে ফাইল আপলোড/সেটিংসের জন্য কম্পিউটার সুবিধাজনক। প্রকাশিত `onrender.com` লিংক মোবাইলেও খোলা যাবে।

## Production-এ যাওয়ার আগে আবশ্যক

1. SQLite-কে স্থায়ী PostgreSQL database-এ migrate এবং backup চালু।
2. Local upload বদলে Cloudinary/S3-এর মতো persistent object storage।
3. SMS provider দিয়ে বাস্তব OTP, মেয়াদ, resend/attempt limit এবং abuse protection।
4. Google/Facebook OAuth-এর server-side token verification।
5. অনুমোদিত merchant account ও official payment gateway integration; server-side payment verification/webhook।
6. Admin panel, seller verification, commission/payout, returns/refunds, delivery integration, audit log, security review ও privacy policy।
7. বাস্তব ব্যবসায়িক ব্যবহার শুরু করার আগে hosting-এর paid/production উপযোগী plan ও data backup নিশ্চিত করা।
